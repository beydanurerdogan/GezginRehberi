package com.example.GezginRehber;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GezginRehberApplicationTests {

	@Test
	void contextLoads() {
	}

}
