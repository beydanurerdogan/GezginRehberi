package com.example.GezginRehber.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "friends")
@Getter
@Setter
public class Friends {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private Long userId1;
    @Column(nullable = false)
    private Long userId2;
    @Column(nullable = false)
    private String status;

    @ManyToMany
    private Users user;
}
