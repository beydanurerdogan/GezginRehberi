package com.example.GezginRehber.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Table(name = "destination")
@Getter
@Setter
public class Destination {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private Long tripId;
    @Column(nullable = false)
    private String locationName;
    @Column(nullable = false)
    private Double latitude;
    @Column(nullable = false)
    private Double longitude;
    @Column(nullable = false)
    private LocalDate visitDate;

    @OneToOne
    private Trips trips;

    @OneToOne
    private Reviews reviews;
}
