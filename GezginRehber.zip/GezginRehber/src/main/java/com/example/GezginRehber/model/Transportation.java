package com.example.GezginRehber.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Table(name = "transportation")
@Setter
@Getter
public class Transportation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private Long tripId;
    @Column(nullable = false)
    private String transportType;
    @Column(nullable = false)
    private Double cast;
    @Column(nullable = false)
    private LocalDate departureTime;
    @Column(nullable = false)
    private LocalDate arrivalTime;

    @OneToOne
    private Trips trips;

}
