package com.example.GezginRehber;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GezginRehberApplication {

	public static void main(String[] args) {
		SpringApplication.run(GezginRehberApplication.class, args);
	}

}
