package com.example.GezginRehber.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.springframework.cglib.core.Local;

import java.time.LocalDate;

@Entity
@Table(name = "expences")
@Getter
@Setter
public class Expenses {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private Long tripId;
    @Column(nullable = false)
    private String categoriy;
    @Column(nullable = false)
    private Double amount;
    @Column(nullable = false)
    private LocalDate expenseDate;

    @OneToOne
    private Trips trips;

}
