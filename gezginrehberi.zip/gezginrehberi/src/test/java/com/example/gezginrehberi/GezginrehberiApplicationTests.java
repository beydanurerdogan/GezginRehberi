package com.example.gezginrehberi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GezginrehberiApplicationTests {

	@Test
	void contextLoads() {
	}

}
