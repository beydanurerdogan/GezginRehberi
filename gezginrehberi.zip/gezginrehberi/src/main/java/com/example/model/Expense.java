package com.example.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

@Entity
@Table(name = "expenses")
@Data
class Expense {
    @Id
    @GeneratedValue(generator = "UUID")
    private UUID expenseId;

    @ManyToOne
    @JoinColumn(name = "trip_id", nullable = false)
    private Trip trip;

    @Column(nullable = false, length = 50)
    private String category;

    @Column(precision = 10, scale = 2)
    private BigDecimal amount;

    private LocalDate expenseDate;
}