package com.example.model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "transportation")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
class Transportation {
    @Id
    @GeneratedValue(generator = "UUID")
    private UUID transportId;

    @ManyToOne
    @JoinColumn(name = "trip_id", nullable = false)
    private Trip trip;

    @Column(nullable = false, length = 50)
    private String transportType;

    @Column(precision = 10, scale = 2)
    private BigDecimal cost;

    private LocalDateTime departureTime;
    private LocalDateTime arrivalTime;
}