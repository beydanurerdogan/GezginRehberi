package com.example.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

@Entity
@Table(name = "destinations")
@Data
class Destination {
    @Id
    @GeneratedValue(generator = "UUID")
    private UUID destinationId;

    @ManyToOne
    @JoinColumn(name = "trip_id", nullable = false)
    private Trip trip;

    @Column(nullable = false, length = 150)
    private String locationName;

    private BigDecimal latitude;
    private BigDecimal longitude;
    private LocalDate visitDate;
}
