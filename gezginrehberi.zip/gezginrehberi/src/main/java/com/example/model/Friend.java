package com.example.model;

import jakarta.persistence.*;
import lombok.*;
import java.util.UUID;

@Entity
@Table(name = "friends")
@Data
class Friend {
    @Id
    @GeneratedValue(generator = "UUID")
    private UUID friendshipId;

    @ManyToOne
    @JoinColumn(name = "user_id_1", nullable = false)
    private User user1;

    @ManyToOne
    @JoinColumn(name = "user_id_2", nullable = false)
    private User user2;

    @Column(nullable = false, length = 20, columnDefinition = "VARCHAR(20) DEFAULT 'pending'")
    private String status = "pending";
}
