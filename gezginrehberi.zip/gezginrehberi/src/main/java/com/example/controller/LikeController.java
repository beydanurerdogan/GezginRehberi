package com.example.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.*;
import com.example.service.LikeService;

@RestController
@RequestMapping("/likes")
public class LikeController {
    private final LikeService likeService;

    public LikeController(LikeService likeService) {
        this.likeService = likeService;
    }

    @PostMapping("/{postId}")
    public ResponseEntity<Like> likePost(@PathVariable UUID postId, @RequestBody Like like) {
        return ResponseEntity.ok(likeService.likePost(like));
    }

    @GetMapping("/{postId}")
    public ResponseEntity<List<Like>> getLikes(@PathVariable UUID postId) {
        return ResponseEntity.ok(likeService.getLikesByPost(new Post()));
    }
}