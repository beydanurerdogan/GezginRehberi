package com.example.controller;

import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Follow;
import com.example.service.FollowService;

@RestController
@RequestMapping("/follow")
public class FollowController {
    private final FollowService followService;

    public FollowController(FollowService followService) {
        this.followService = followService;
    }

    @PostMapping("/add")
    public ResponseEntity<Follow> followUser(@RequestBody Follow follow) {
        return ResponseEntity.ok(followService.followUser(follow));
    }

    @DeleteMapping("/remove/{id}")
    public ResponseEntity<String> unfollowUser(@PathVariable UUID id) {
        followService.unfollowUser(id);
        return ResponseEntity.ok("Unfollowed successfully");
    }

}
