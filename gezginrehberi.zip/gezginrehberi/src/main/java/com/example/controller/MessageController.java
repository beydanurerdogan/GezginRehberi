package com.example.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.MessageRequest;
import com.example.model.Message;
import com.example.model.User;
import com.example.repository.UserRepository;
import com.example.service.MessageService;

@RestController
@RequestMapping("/messages")
public class MessageController {
    private final MessageService messageService;
    private final UserRepository userRepository;

    public MessageController(MessageService messageService, UserRepository userRepository) {
        this.messageService = messageService;
        this.userRepository = userRepository;
    }

    @PostMapping("/send")
    public ResponseEntity<Message> sendMessage(@RequestBody MessageRequest request) {
        User sender = userRepository.findByUsername(request.getSender())
                .orElseThrow(() -> new RuntimeException("User not found"));
        User receiver = userRepository.findByUsername(request.getReceiver())
                .orElseThrow(() -> new RuntimeException("User not found"));
        Message message = messageService.sendMessage(sender, receiver, request.getContent());
        return ResponseEntity.ok(message);
    }

    @GetMapping("/{sender}/{receiver}")
    public ResponseEntity<List<Message>> getMessages(@PathVariable String sender, @PathVariable String receiver) {
        User senderUser = userRepository.findByUsername(sender)
                .orElseThrow(() -> new RuntimeException("User not found"));
        User receiverUser = userRepository.findByUsername(receiver)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return ResponseEntity.ok(messageService.getMessages(senderUser, receiverUser));
    }
}
