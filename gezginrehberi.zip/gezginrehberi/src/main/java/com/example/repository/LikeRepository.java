package com.example.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.*;

public interface LikeRepository extends JpaRepository<Like, UUID> {
    List<Like> findByPost(Post post);
}
