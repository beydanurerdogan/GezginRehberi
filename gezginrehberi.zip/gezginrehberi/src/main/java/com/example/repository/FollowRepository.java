package com.example.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.Follow;
import com.example.model.User;

public interface FollowRepository extends JpaRepository<Follow, UUID> {
    List<Follow> findByFollower(User follower);

    List<Follow> findByFollowing(User following);
}
