package com.example.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.model.Post;

public interface PostRepository extends JpaRepository<Post, UUID> {

    List<Post> findByContentContaining(String query);
}
