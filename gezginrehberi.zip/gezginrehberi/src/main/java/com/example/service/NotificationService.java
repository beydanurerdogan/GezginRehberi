package com.example.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.model.Notification;
import com.example.model.User;
import com.example.repository.NotificationRepository;

@Service
public class NotificationService {
    private final NotificationRepository notificationRepository;

    public NotificationService(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    public Notification createNotification(User user, String message) {
        Notification notification = new Notification();
        return notificationRepository.save(notification);
    }

    public List<Notification> getNotifications(User user) {
        return notificationRepository.findByUser(user);
    }

}
