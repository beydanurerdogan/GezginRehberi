package com.example.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.model.Like;
import com.example.model.Post;
import com.example.repository.LikeRepository;

 @Service
public class LikeService {
    private final LikeRepository likeRepository;
    
    public LikeService(LikeRepository likeRepository) {
        this.likeRepository = likeRepository;
    }
    
    public Like likePost(Like like) {
        return likeRepository.save(like);
    }
    
    public List<Like> getLikesByPost(Post post) {
        return likeRepository.findByPost(post);
    }
}
