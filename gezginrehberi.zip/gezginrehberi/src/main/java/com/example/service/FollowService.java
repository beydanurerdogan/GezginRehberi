package com.example.service;

import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.example.model.Follow;
import com.example.model.User;
import com.example.repository.FollowRepository;

@Service
public class FollowService {
    private final FollowRepository followRepository;

    public FollowService(FollowRepository followRepository) {
        this.followRepository = followRepository;
    }

    public Follow followUser(Follow follow) {
        return followRepository.save(follow);
    }

    public void unfollowUser(UUID id) {
        followRepository.deleteById(id);
    }

    public List<Follow> getFollowers(User user) {
        return followRepository.findByFollowing(user);
    }

    public List<Follow> getFollowing(User user) {
        return followRepository.findByFollower(user);
    }

}
